// Copyright 2018 Peter Dimov
// Distributed under the Boost Software License, Version 1.0.

#if defined(_WIN32) || defined(__WIN32__) || defined(__CYGWIN__)
# include <windows.h>
# include <boost/shared_ptr.hpp>
#endif

int main()
{
}
