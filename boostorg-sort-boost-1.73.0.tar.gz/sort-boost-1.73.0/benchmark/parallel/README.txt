README.TXT
==============
If you want to do manually or with different compiler.

file_generator is a program which generte a file with random information 
               for to be used in the benchmark.
               After compiled the invocation is
               ./file_generator input.bin 1250000000
               
Now we have the data file and only need to compile and run the programs.
				benchmark_objects.cpp
				benchmark_strings.cpp
				benchmark_numbers.cpp

They show a detailed information on the screen in a compact mode              
