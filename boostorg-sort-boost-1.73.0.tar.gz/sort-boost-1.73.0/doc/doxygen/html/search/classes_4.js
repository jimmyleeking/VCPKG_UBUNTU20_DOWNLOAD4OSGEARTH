var searchData=
[
  ['negrightshift',['negrightshift',['../structnegrightshift.html',1,'']]]
];
