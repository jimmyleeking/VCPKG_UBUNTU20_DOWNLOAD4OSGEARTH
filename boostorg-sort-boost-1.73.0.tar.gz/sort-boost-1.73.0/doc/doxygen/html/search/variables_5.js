var searchData=
[
  ['last_5fname',['last_name',['../struct_d_a_t_a___t_y_p_e.html#a12df0589010b4a79d824dbea9326ba43',1,'DATA_TYPE']]]
];
