var searchData=
[
  ['data_5ftype',['DATA_TYPE',['../struct_d_a_t_a___t_y_p_e.html',1,'']]]
];
