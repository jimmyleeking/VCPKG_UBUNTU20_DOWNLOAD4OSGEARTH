.. Metafunctions/Arithmetic Operations/multiplies |70

multiplies
==========


``multiplies`` is a synonym for |times|. It is Provided for backward compatibility with
earlier versions of the library. See |times| for the detailed specification.


.. copyright:: Copyright �  2001-2009 Aleksey Gurtovoy and David Abrahams
   Distributed under the Boost Software License, Version 1.0. (See accompanying
   file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
