#ifndef BOOST_METAPARSE_GETTING_STARTED_1_1_HPP
#define BOOST_METAPARSE_GETTING_STARTED_1_1_HPP

// Automatically generated header file

// Definitions before section 1
#include "1.hpp"

// Definitions of section 1

#endif

