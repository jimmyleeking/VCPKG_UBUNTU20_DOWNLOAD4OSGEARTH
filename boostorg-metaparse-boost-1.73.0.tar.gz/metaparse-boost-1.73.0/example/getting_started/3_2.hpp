#ifndef BOOST_METAPARSE_GETTING_STARTED_3_2_HPP
#define BOOST_METAPARSE_GETTING_STARTED_3_2_HPP

// Automatically generated header file

// Definitions before section 3.1
#include "3_1.hpp"

// Definitions of section 3.1
// query:
//    exp_parser1::apply<BOOST_METAPARSE_STRING("thirteen")>::type

#endif

