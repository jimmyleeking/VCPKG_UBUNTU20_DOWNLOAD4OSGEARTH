#ifndef BOOST_METAPARSE_GETTING_STARTED_6_1_HPP
#define BOOST_METAPARSE_GETTING_STARTED_6_1_HPP

// Automatically generated header file

// Definitions before section 6
#include "6.hpp"

// Definitions of section 6

#endif

