#ifndef BOOST_METAPARSE_GETTING_STARTED_5_1_HPP
#define BOOST_METAPARSE_GETTING_STARTED_5_1_HPP

// Automatically generated header file

// Definitions before section 5
#include "5.hpp"

// Definitions of section 5

#endif

