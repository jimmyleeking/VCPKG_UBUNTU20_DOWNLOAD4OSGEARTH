#ifndef BOOST_METAPARSE_GETTING_STARTED_5_2_1_HPP
#define BOOST_METAPARSE_GETTING_STARTED_5_2_1_HPP

// Automatically generated header file

// Definitions before section 5.2
#include "5_2.hpp"

// Definitions of section 5.2
using temp_result = exp_parser7::apply<BOOST_METAPARSE_STRING("1 + 2 + 3 + 4")>::type;

#endif

