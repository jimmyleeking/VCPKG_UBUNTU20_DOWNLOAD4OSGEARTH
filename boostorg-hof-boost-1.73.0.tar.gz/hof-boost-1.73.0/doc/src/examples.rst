.. Copyright 2018 Paul Fultz II
   Distributed under the Boost Software License, Version 1.0.
   (http://www.boost.org/LICENSE_1_0.txt)

Examples
========

.. toctree::
    :maxdepth: 1

    example_print
    example_overloading
    example_polymorphic_constructors
    more_examples