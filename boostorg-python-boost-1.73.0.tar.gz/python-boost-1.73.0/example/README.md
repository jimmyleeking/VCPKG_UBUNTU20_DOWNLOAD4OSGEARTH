![logo](https://raw.githubusercontent.com/boostorg/python/develop/doc/images/bpl.png)

# Examples

This directory contains various examples using Boost.Python.
You may compile these using the `bjam` command either in this directory
or in any of the subdirectories.
You may need to adjust the paths in the Jamroot file if Boost.Python
is not installed in a default location.
See http://boostorg.github.io/python/doc/html/building/no_install_quickstart.html
for details.
