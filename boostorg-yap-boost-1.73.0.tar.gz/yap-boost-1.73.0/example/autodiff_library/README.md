autodiff_library
================ <\br>

Automatic Differentiation Library <br>
1. Very easy access and light weight c++/c library <br>
2. Build computation graph as a DAG. <br>
3. Provide function evaluation, reverse gradient, reverse Hessian-vector, forward Hessian computation calls.<br>
4. State-of-the-art Object-Oriented Design and Implementation in C++ <br>
5. A modified version of this library is integrated into the Parallel Structured Model Generator(PSMG)--an algebraic modelling langauge for Mathematical Programming.
See project wiki for more detail.
