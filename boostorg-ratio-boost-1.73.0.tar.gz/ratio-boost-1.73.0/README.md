ratio
======

Compile time rational arithmetic. C++11.

### License

Distributed under the [Boost Software License, Version 1.0](http://boost.org/LICENSE_1_0.txt).
