var classboost_1_1locale_1_1collator__base =
[
    [ "level_type", "classboost_1_1locale_1_1collator__base.html#a73c12de809733273304fef7f0af28b22", [
      [ "primary", "classboost_1_1locale_1_1collator__base.html#a73c12de809733273304fef7f0af28b22ae57e842f398a27ee490208f5af39675b", null ],
      [ "secondary", "classboost_1_1locale_1_1collator__base.html#a73c12de809733273304fef7f0af28b22ad8e103443d69f03f00ac4b68a7181866", null ],
      [ "tertiary", "classboost_1_1locale_1_1collator__base.html#a73c12de809733273304fef7f0af28b22a3a852752e9663b7b3340c435d0cfe36a", null ],
      [ "quaternary", "classboost_1_1locale_1_1collator__base.html#a73c12de809733273304fef7f0af28b22a22ca1875fd63667fbb018df16b0aedba", null ],
      [ "identical", "classboost_1_1locale_1_1collator__base.html#a73c12de809733273304fef7f0af28b22a3c209055ff840e311581ab43013026f2", null ]
    ] ]
];