var annotated =
[
    [ "boost", null, [
      [ "locale", "namespaceboost_1_1locale.html", "namespaceboost_1_1locale" ],
      [ "shared_ptr", "classboost_1_1shared__ptr.html", null ]
    ] ]
];