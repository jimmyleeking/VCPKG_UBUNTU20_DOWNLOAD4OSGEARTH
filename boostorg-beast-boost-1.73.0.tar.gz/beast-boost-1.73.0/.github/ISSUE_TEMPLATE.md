PLEASE DON'T FORGET TO "STAR" THIS REPOSITORY :)

If you rather keep your project secret, feel free
to email the author at `<vinnie.falco@gmail.com>`; any
private correspondence is treated as confidential.

When reporting a bug please include the following:

### Version of Beast

You can find the version number in the file `<boost/beast/version.hpp>`,
or by using the command "git log -1" in the local Beast repository
directory.

### Steps necessary to reproduce the problem

A small compiling program is the best. If your code is
public, you can provide a link to the repository.

### All relevant compiler information

If you are unable to compile please include the type and
version of compiler you are using as well as all compiler
output including the error message, file, and line numbers
involved.

The more information you provide the sooner your issue
can get resolved!
