/*=============================================================================
    Boost.Wave: A Standard compliant C++ preprocessor library
    http://www.boost.org/

    Copyright (c) 2001-2012 Hartmut Kaiser. Distributed under the Boost
    Software License, Version 1.0. (See accompanying file
    LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
=============================================================================*/


//E t_9_028.cpp(12): error: could not find include file: utf8-test-ßµ™∃/file.hpp
#include <utf8-test-ßµ™∃/file.hpp>

