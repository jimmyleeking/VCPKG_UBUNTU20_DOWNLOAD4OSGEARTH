import sys
open(sys.argv[2], "w").write(open(sys.argv[1]).read())
